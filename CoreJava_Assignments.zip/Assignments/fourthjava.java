public class fourthjava {
    public static void main( String[] args )
    {
        // Initialzing the variable
        int cars; 
        int drivers;
        int passengers;
        int cars_not_driven;
        int cars_driven;

        // Initialzing the variable
        double space_in_a_car;
        double carpool_capacity;
        double average_passengers_per_car;
 
        // Assigning the variable 
        cars = 100;
        space_in_a_car = 4.0;
        drivers = 30;
        passengers = 90;

        // Re-Assigning the variable or applying operations
        cars_not_driven = cars - drivers;
        cars_driven = drivers;
        carpool_capacity = cars_driven * space_in_a_car;
        average_passengers_per_car = passengers / cars_driven;
 
        // using variable in println and printing them with string
        System.out.println( "There are " + cars + " cars available." ); 
        System.out.println( "There are only " + drivers + " drivers available." );
        System.out.println( "There will be " + cars_not_driven + " empty cars today." );
        System.out.println( "We can transport " + carpool_capacity + " people today." );
        System.out.println( "We have " + passengers + " to carpool today." );
        System.out.println( "We need to put about " + average_passengers_per_car + " in each car." );
    }

}
