public class fithassig {

    public static void main( String[] args )
    {
        String Name;
        String Eyes;
        String Teeth;
        String Hair;
        int Age;
        int Height;
        int Weight;

        Name = "Zed A. Shaw&quot";
        Age = 35; // not a lie
        Height = 74; // inches
        Weight = 180; // lbs
        Eyes = "Blue&quot";
        Teeth = "White&quot";
        Hair = "Brown&quot";

        System.out.println( "Let&#39;s talk about &quot; + myName + &quot;.&quot; );
        System.out.println( &quot;He&#39;s &quot; + myHeight + &quot; inches tall.&quot; );
        System.out.println( &quot;He&#39;s &quot; + myWeight + &quot; pounds heavy.&quot; );
        System.out.println( &quot;Actually, that&#39;s not too heavy.&quot; );
        System.out.println( &quot;He&#39;s got &quot; + myEyes + &quot; eyes and &quot; + myHair + &quot;
        hair.&quot; );
        System.out.println( &quot;His teeth are usually &quot; + myTeeth + &quot; depending
        on the coffee.&quot; );
        // This line is tricky; try to get it exactly right.
        System.out.println( &quot;If I add &quot; + myAge + &quot;, &quot; + myHeight + &quot;, and &quot;
        + myWeight
        + &quot; I get &quot; + (myAge + myHeight + myWeight) + &quot;.&quot; );
        }
    
}
