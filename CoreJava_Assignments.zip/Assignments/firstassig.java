public class firstassig {

    public static void main(String[] args) {
        System.out.println("+-------------------------+");
        System.out.println("|                    #### |");
        System.out.println("|                    #### |");
        System.out.println("|                    #### |");
        System.out.println("|                         |");
        System.out.println("|                         |");
        System.out.println("|          Akash          |");
        System.out.println("|          Thakur village |");
        System.out.println("|          Mumbai         |");
        System.out.println("|                         |");
        System.out.println("+-------------------------");
    }
}