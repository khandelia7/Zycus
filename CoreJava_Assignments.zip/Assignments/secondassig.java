public class secondassig {
    public static void main(String[] args) {
        System.out.println("For the name Akash Rajesh Khandelia");
        System.out.println("  A     RRRR      K   K");
        System.out.println(" A A    R    R    K  K");
        System.out.println("A   A   R    R    K K");
        System.out.println("AAAAA   RRRR      KK");
        System.out.println("A   A   R R       K  K");
        System.out.println("A   A   R  R      K   K");
        System.out.println("A   A   R   R     K    K");
    }
}
