package com.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Benificiary {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long ssn;

	//@ManyToOne(cascade = {CascadeType.ALL},fetch= FetchType.EAGER)
	private String name;

	public Benificiary() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Benificiary(String name) {
		super();
		this.name = name;
	}

	public Benificiary(Long ssn, String name) {
		super();
		this.ssn = ssn;
		this.name = name;
	}

	public Long getSsn() {
		return ssn;
	}

	public void setSsn(Long ssn) {
		this.ssn = ssn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
