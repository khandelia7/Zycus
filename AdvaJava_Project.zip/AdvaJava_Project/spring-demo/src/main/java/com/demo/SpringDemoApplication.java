package com.demo;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.demo.entities.Account;
import com.demo.services.BankService;
import com.demo.services.BankServiceImpl;

@SpringBootApplication
public class SpringDemoApplication {
	
	@Autowired 
	BankService bankService;
	

	public static void main(String[] args) throws SQLException {
		ApplicationContext context = SpringApplication.run(SpringDemoApplication.class, args);
		BankService bankService = context.getBean(BankService.class);
		
//		Account account = new Account("Akash khandelia", true, 6000, "mno@gmail.com", "jaipur", "India");
//		Account account1 = new Account("khandelia", true, 2000, "xyz@gmail.com", "mumbai", "India");
//		bankService.createNewAccount(account);
//		bankService.createNewAccount(account1);
//		List<Account> accounts = bankService.getAllAccounts();
//		for(Account acc: accounts) {
//			System.out.println(acc.getBalance());
//		}
		
//		bankService.deActivateAccount(1L);
		
		// bankService.transfer(1L, 7L, 100);
		
		// bankService.credit(100, 1L);
		
		bankService.debit(400, 1L);
	
		
	}
	
	

}
