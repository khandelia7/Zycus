package com.zycus.entities;

public class Employee {

}
