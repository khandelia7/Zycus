package com.zycus.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity // make this class as table in database
@Table(name = "employee") // change table name
public class Employee {

	@Id // primary key
	@GeneratedValue(strategy = GenerationType.AUTO) // auto increment
	private Long employeeID;

	private String name;

	private Double salary;

//	One employee has Many manager [Employee side] : 1:M 
//	One manager has many employee [Manager Side] :  M to 1
//  Note In employee no need to mention course

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(Long employee_id, String name, Double salary) {
		super();
		this.employeeID = employee_id;
		this.name = name;
		this.salary = salary;
	}

	public Employee(String name, Double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	public Long getEmployee_id() {
		return employeeID;
	}

	public void setEmployee_id(Long employee_id) {
		this.employeeID = employee_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

}
