package com.zycus.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.zycus.entities.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long>{
	
	// JPQL
	@Query("select d from Department d join d.manager m join m.employee e where e.employeeID=?1")
	List<Department> fetchDepartmentByEmployeeName(Long id); 
}
