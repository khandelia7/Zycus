package com.zycus.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.zycus.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // native query
	@Query(value = "SELECT employee.name from manager, employee where manager.managerID = employee.employeeID AND manager.name=?1", nativeQuery = true)
	String getEmployeeByManagerName(String cname);

//	// JPQL
	@Query("select i from manager m join m.employee i where m.name=?1")
	List<Employee> getEmployeeByManagerNameJPQL(String cname);

}
