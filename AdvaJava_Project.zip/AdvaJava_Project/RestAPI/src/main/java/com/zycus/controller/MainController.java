package com.zycus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zycus.entities.Employee;
import com.zycus.entities.Manager;
import com.zycus.repository.EmployeeRepository;
import com.zycus.repository.ManagerRepository;

@RestController
public class MainController {

	// always Auto-wired and not make a object
	@Autowired
	private ManagerRepository managerRepository;

	@Autowired
	private EmployeeRepository employeeRepository;

	// 1st API of simple hello
	@GetMapping("/hello")
	public String helloMethod() {
		// int i = 9/0;
		return "Hello World";
	}

	// 2nd & 8th API of POST Mapping API in which we will add manager plus
	// employee-id is also updated
	// Very Important that in URL itself we are passing the ID
	@PostMapping("/add-manager/{employeeID}")
	public Manager postmanager(@PathVariable("employeeID") long employeeID, @RequestBody Manager manager) {
		// System.out.println("manager: " + manager);
		Employee employee = employeeRepository.getOne(employeeID);
		if (employee == null) {
			throw new RuntimeException("ID does not exist");
		} else {
			manager.setEmployee(employee);
			return managerRepository.save(manager);
		}
	}

	// 3rd API of GET Mapping API in which courses and discounted value is given
	@GetMapping("/get-manager")
	public List<Manager> getManager() {
		Manager manager = new Manager();
		List<Manager> list = managerRepository.findAll();
		return list;
	}

	// 4th API of DELETE API in which we will delete course
	@DeleteMapping("/delete-manager/{managerID}") // passing arguments
	public void deleteManager(@PathVariable("managerID") long managerID) {
		managerRepository.deleteById(managerID);
	}

	// 5th API of PUT API in which we will modify/edit course
	@PutMapping("/edit-manager/{managerID}") // passing arguments
	public Manager editManger(@PathVariable("managerID") long managerID, @RequestBody Manager managerUpdate) {
		// courseUpdated is body which has to be edited
		// courseDB is temporary object which will edit the things for u
		Manager managerDB = managerRepository.getOne(managerID);
		managerDB.setName(managerUpdate.getName());
		managerUpdate.getMobileNumber();
		return managerRepository.save(managerDB);
	}

	// 6th API of GET API in which paging (optional too) will be perform
	@GetMapping("/paging-manager")
	public List<Manager> getManagerPaging(
			@RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
			@RequestParam(value = "size", required = false, defaultValue = "1000") Integer size) {
		// we will take 2 parameter page and size with flag and defaultValue as
		// parameter
		// This two things will make paging optional
		// Problem of paging is re-solve

		// Always use in built function algorithm
		Pageable pageable = PageRequest.of(page, size);
		List<Manager> list = managerRepository.findAll(pageable).getContent();
		return list;
	}

	// 7th API of GET API in which filter (sorting) will be perform
	@GetMapping("/filter-manager")
	public List<Manager> getManagerSort(
			@RequestParam(value = "page", required = false, defaultValue = "0") Integer page,
			@RequestParam(value = "size", required = false, defaultValue = "1000") Integer size,
			@RequestParam(value = "sort", required = false, defaultValue = "ASC") String direction,
			@RequestParam(value = "sortParam", required = false, defaultValue = "name") String sortParam) {
		// 4 parameter page, size, sort (defaultValue ASC) & sortParam (other than price
		// sorting)
		Manager dto = new Manager();

		Sort sort; // ASC or DESC condition check
					// other parameter (except price) is also sort
		if (direction.equals("ASC")) {
			sort = Sort.by(Sort.Direction.ASC, sortParam);
		} else {
			sort = Sort.by(Sort.Direction.DESC, sortParam);
		}

		Pageable pageable = PageRequest.of(page, size, sort);
		List<Manager> list = managerRepository.findAll(pageable).getContent();

		return list;
	}

	// 9th GET API Based on Manager manager_name fetch all Manager
	@GetMapping("/course/name/{name}")
	public List<Manager> getManagerList(@PathVariable("name") String name) {
		return managerRepository.findAllByName(name);
	}

	// 10th GET API Fetch all manager based on employee name
	@GetMapping("/manager/employee/{name}")
	public List<Manager> getManagerListByEmployeeName(@PathVariable("name") String name) {
		return managerRepository.findAllByEmployeeName(name);
	}

}
