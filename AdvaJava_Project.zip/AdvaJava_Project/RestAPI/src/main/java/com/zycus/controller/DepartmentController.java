package com.zycus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.zycus.entities.Department;
import com.zycus.repository.DepartmentRepository;
import com.zycus.repository.ManagerRepository;

public class DepartmentController {
	
	@Autowired
	private DepartmentRepository departmentRepository;
	
	@Autowired
	private ManagerRepository managerRepository;

	// Put student details
	@PostMapping("/department")
	public Department postStudent(@RequestBody Department department){
		return departmentRepository.save(department);
	}
	
	// Get students details
	@GetMapping("/department")
	public List<Department> getALlStudents(){
		return departmentRepository.findAll();
	}

}
