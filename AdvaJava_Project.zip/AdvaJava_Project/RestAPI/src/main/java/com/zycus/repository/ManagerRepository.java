package com.zycus.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zycus.entities.Manager;

//we will access database table through JpaRepository and not by firing query
//make interface and extend it so that we wont have to over-ride all method
//Long is nothing but the data-type of the ID of Manager primary key
public interface ManagerRepository extends JpaRepository<Manager, Long>{
	
	// Based on Manager price fetch all courses
	List<Manager> findAllByName(String name);
		
	// Fetch all manager based on Employee name
	List<Manager> findAllByEmployeeName(String name);

}
