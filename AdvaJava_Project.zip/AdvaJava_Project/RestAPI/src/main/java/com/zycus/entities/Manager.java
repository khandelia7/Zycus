package com.zycus.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity // make this class as table in database
@Table(name = "manager") // change table name
public class Manager implements Comparable<Manager> {

	@Id // primary key // Very Important
	@GeneratedValue(strategy = GenerationType.AUTO) // auto increment
	// Hibernate Sequence
	private Long managerID; // Always keep a class and not primitive

	@Column(name = "manager_name") // change column name
	private String name;

	private String mobileNumber;

//	One  employee has Many manager [employee side] : 1:M 
//	One manager has many employee [Manager Side] :  M to 1
	@ManyToOne //change
	private Employee employee;

	@ManyToMany(mappedBy = "manager")
	List<Department> departments;

	public Long getManagerID() {
		return managerID;
	}

	public void setManagerID(Long managerID) {
		this.managerID = managerID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public List<Department> getDepartments() {
		return departments;
	}

	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}

	@Override
	public String toString() {
		return "Manager [managerID=" + managerID + ", name=" + name + ", mobileNumber=" + mobileNumber + ", employee="
				+ employee + ", departments=" + departments + "]";
	}

	@Override
	public int compareTo(Manager o) {
		// TODO Auto-generated method stub
		boolean status = this.getManagerID().equals(o.getManagerID());
		return status ? 0 : 1;
	}
}
