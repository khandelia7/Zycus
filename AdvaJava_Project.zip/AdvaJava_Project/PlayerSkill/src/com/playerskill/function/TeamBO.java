package com.playerskill.function;

import com.playerskill.beans.Player;
import com.playerskill.beans.Team;

public class TeamBO {
	
	/* In this method, parse the string data using Split method defined in the string class and and construct a team object.
	Iterate through the playerList and get the player object reference. */
	
	public Team createTeam(String data, Player[] PlayerList) {
		return null;
	}
}
